package com.MyComapany.propertymanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PropertyManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
